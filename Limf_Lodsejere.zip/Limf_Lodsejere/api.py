import time
import requests
from datetime import datetime, timezone
from xml.etree import ElementTree as ET
from qgis.core import QgsGeometry

# OAuth-token cache: {client_id: {'token': str, 'expires': float}}
_token_cache: dict[str, dict] = {}


class DatafordelerClient:
    """Geometri og ejeroplysninger via Datafordeleren (OAuth Shared Secret)."""

    WFS_URL = 'https://wfs.datafordeler.dk/MATRIKLEN2/MatGaeldendeOgForeloebigWFS/1.0.0/WFS'

    # Ejerforholdskoder efter den fælles grunddata-kodeliste (ESR-afledt,
    # samme liste som BBR bruger — se teknik.bbr.dk/kodelister). Teksterne
    # er de officielle; kun 90 er forkortet, da den fylder 140 tegn.
    #
    # Fem af koderne var tidligere forkerte: 20 og 30 var byttet om (alment
    # boligselskab kaldtes aktieselskab), og 60 og 80 var byttet om (anden
    # kommune kaldtes staten). 41 manglede, og 90 blev kaldt "anden
    # offentlig ejer", selvom den netop dækker blandet og privat ejerskab.
    EJERFORHOLD = {
        '10': 'Privatpersoner eller interessentskab',
        '20': 'Alment boligselskab',
        '30': 'Aktie-, anpart- eller andet selskab (undtagen interessentskab)',
        '40': 'Forening, legat eller selvejende institution',
        '41': 'Privat andelsboligforening',
        '50': 'Den kommune, hvori ejendommen er beliggende',
        '60': 'Anden primærkommune',
        '70': 'Region',
        '80': 'Staten',
        '90': 'Andet, herunder moderejendomme og ejendomme med flere '
              'kategorier af ejere',
        '99': 'Ikke beregnet',
    }

    TOKEN_URL   = 'https://auth.datafordeler.dk/realms/distribution/protocol/openid-connect/token'
    GRAPHQL_URL = 'https://graphql.datafordeler.dk/flexibleCurrent/v1/'

    def __init__(self, client_id: str, client_secret: str, wfs_apikey: str):
        self._client_id     = client_id
        self._client_secret = client_secret
        self._wfs_apikey    = wfs_apikey
        self.session = requests.Session()
        self.session.headers['User-Agent'] = (
            'Lodsejere QGIS Plugin / Limfjordssekretariatet'
        )
        #: Sat hvis serveren afviser cprAdresse-feltet — så spørges der uden
        #: postnummer resten af kørslen (se get_ejer).
        self._uden_cpradresse = False

    # ------------------------------------------------------------------
    # Fejlhåndtering
    # ------------------------------------------------------------------

    @staticmethod
    def _fejltekst(resp) -> str:
        """Den forklarende del af svaret, uden JSON-støj og trace-id.

        Datafordelerens GraphQL svarer med en errors-liste, hvor hver fejl
        har sit eget traceId. Tages hele kroppen med, bliver ellers ens
        fejl unikke, og otte afviste opslag ser ud som otte forskellige
        problemer. Her tages kun beskeden, fejlkoden og den ressource der
        blev afvist.
        """
        try:
            data = resp.json()
        except ValueError:
            return ' '.join((resp.text or '').split())[:300]
        if not isinstance(data, dict):
            return ' '.join((resp.text or '').split())[:300]

        fejl = (data.get('errors') or [{}])[0]
        dele = [fejl.get('message') or '']
        kode = (fejl.get('extensions') or {}).get('code')
        if kode:
            dele.append(f'kode {kode}')
        sti = fejl.get('path') or []
        if sti:
            dele.append('ressource: ' + ', '.join(str(s) for s in sti))
        tekst = ' — '.join(d for d in dele if d)
        return tekst or ' '.join((resp.text or '').split())[:300]

    @classmethod
    def _tjek_svar(cls, resp, hvad: str) -> None:
        """Rejs en fejl der siger HVORFOR, ikke bare hvilken statuskode.

        requests' raise_for_status() giver kun "403 Client Error: Forbidden
        for url: ...". Datafordeleren skriver som regel årsagen i svarets
        krop, og uden den står brugeren uden noget at handle på.
        """
        if resp.ok:
            return
        krop = cls._fejltekst(resp)
        besked = f'{hvad} fejlede: HTTP {resp.status_code}'
        if krop:
            besked += f' — {krop}'
        if resp.status_code in (401, 403):
            besked += (
                '\n\nAdgangen blev afvist, selvom log ind lykkedes. Nævnes '
                'en ressource ovenfor, er det præcis den entitet, jeres '
                'ansøgning om dataadgang skal omfatte — se Datafordeler '
                'Administration → Dataadgang, hvor status skal stå som '
                '"Godkendt". Fejlkoden DAF-AUTH-0001 betyder netop det. '
                'Dækker ansøgningen kun virksomhedsdata, kan pluginnet '
                'stadig bruges med "Vis kun virksomhedsejere" — adgang til '
                'personoplysninger godkendes særskilt.'
            )
        raise RuntimeError(besked)

    # ------------------------------------------------------------------
    # OAuth
    # ------------------------------------------------------------------

    def _get_token(self) -> str:
        cached = _token_cache.get(self._client_id)
        if cached and cached['expires'] > time.time() + 30:
            return cached['token']

        resp = self.session.post(
            self.TOKEN_URL,
            data={
                'grant_type':    'client_credentials',
                'client_id':     self._client_id,
                'client_secret': self._client_secret,
            },
            timeout=15,
        )
        self._tjek_svar(resp, 'Log ind på Datafordeleren')
        data       = resp.json()
        token      = data['access_token']
        expires_in = int(data.get('expires_in', 3600))
        _token_cache[self._client_id] = {
            'token':   token,
            'expires': time.time() + expires_in,
        }
        return token

    # ------------------------------------------------------------------
    # Matrikler (WFS)
    # ------------------------------------------------------------------

    @staticmethod
    def _poslist_to_wkt_ring(poslist_text: str) -> str:
        coords = poslist_text.split()
        pairs  = [f'{coords[i]} {coords[i+1]}' for i in range(0, len(coords) - 1, 2)]
        return '(' + ', '.join(pairs) + ')'

    def _gml_surface_to_wkt(self, geometri_el) -> str:
        # Håndterer gml:Polygon og gml:MultiSurface/gml:Surface
        rings = []
        for poslist in geometri_el.iter('{http://www.opengis.net/gml/3.2}posList'):
            rings.append(self._poslist_to_wkt_ring(poslist.text.strip()))
        if not rings:
            return ''
        # Første ring = ydre, resten = huller
        return 'POLYGON(' + ', '.join(rings) + ')'

    NS = {
        'wfs': 'http://www.opengis.net/wfs/2.0',
        'mat': 'http://data.gov.dk/schemas/matrikel/1',
        'gml': 'http://www.opengis.net/gml/3.2',
    }

    def get_jordstykker(self, geometry) -> list[dict]:
        bb   = geometry.boundingBox()
        bbox = f'{bb.xMinimum()},{bb.yMinimum()},{bb.xMaximum()},{bb.yMaximum()},EPSG:25832'

        start_index = 0
        page_size   = 500
        all_features = []

        while True:
            resp = self.session.get(
                self.WFS_URL,
                params={
                    'SERVICE':    'WFS',
                    'REQUEST':    'GetFeature',
                    'VERSION':    '2.0.0',
                    'TYPENAMES':  'mat:Jordstykke_Gaeldende',
                    'BBOX':       bbox,
                    'COUNT':      page_size,
                    'STARTINDEX': start_index,
                    'apikey':     self._wfs_apikey,
                },
                timeout=60,
            )
            self._tjek_svar(resp, 'Opslag af matrikler (Matriklen WFS)')

            root    = ET.fromstring(resp.content)
            members = root.findall('wfs:member', self.NS)
            all_features.extend(members)

            matched   = int(root.get('numberMatched', '0') or '0')
            returned  = int(root.get('numberReturned', '0') or '0')
            start_index += returned
            if start_index >= matched or returned == 0:
                break

        results = []
        for member in all_features:
            js = member.find('mat:Jordstykke_Gaeldende', self.NS)
            if js is None:
                continue

            gml_geom = js.find('mat:geometri', self.NS)
            if gml_geom is None:
                continue

            def txt(tag):
                el = js.find(f'mat:{tag}', self.NS)
                return el.text if el is not None and el.text else ''

            geom_wkt = self._gml_surface_to_wkt(gml_geom)

            bfe_raw = txt('samletFastEjendomLokalId')
            bfe     = str(int(bfe_raw)) if bfe_raw else ''

            results.append({
                'geometri_wkt':   geom_wkt,
                'ejerlavskode':   int(txt('ejerlavskode') or 0),
                'ejerlavsnavn':   '',
                'matrikelnummer': txt('matrikelnummer'),
                'bfe_nummer':     bfe,
            })
        return results

    # ------------------------------------------------------------------
    # Ejeroplysninger — EJF GraphQL
    # ------------------------------------------------------------------

    #: Adressen på ejeren ligger i cprAdresse — standardadresse alene er
    #: kun vej og husnummer, uden postnummer og by. Feltnavnene følger
    #: Datafordelerens transitionsguide for EJF.
    CPR_ADRESSE = """
                        cprAdresse {
                            vejadresseringsnavn
                            husnummer
                            etage
                            sidedoer
                            postnummer
                            postdistrikt
                        }"""

    @staticmethod
    def _er_ukendt_felt(fejl: list) -> bool:
        """Klager GraphQL over et felt vi har spurgt om, frem for om data?"""
        for f in fejl or []:
            besked = (f.get('message') or '').lower()
            if 'cpradresse' in besked:
                return True
            if 'unknown field' in besked or 'ukendt felt' in besked:
                return True
        return False

    def _ejer_query(self, nu: str, bfe_nummer: str, med_postnr: bool) -> str:
        return """
        query {
            EJFCustom_EjerskabBegraenset(
                virkningstid: "%s"
                where: { bestemtFastEjendomBFENr: { eq: %s } }
            ) {
                nodes {
                    bestemtFastEjendomBFENr
                    ejerforholdskode
                    status
                    ejendeVirksomhedCVRNr_20_Virksomhed_CVRNummer_ref {
                        CVRNummer
                        id_CVR_Navn_CVREnhedsId_ref { vaerdi }
                    }
                    ejendePersonBegraenset {
                        navn { navn }
                        standardadresse%s
                        beskyttelser { beskyttelsestype }
                        status
                    }
                }
            }
        }
        """ % (nu, bfe_nummer, self.CPR_ADRESSE if med_postnr else '')

    def get_ejer(self, bfe_nummer: str, only_companies: bool = True) -> dict:
        if not bfe_nummer:
            return self._tomt_ejer()

        token = self._get_token()
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type':  'application/json',
        }

        nu = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S+00:00')

        data = None
        for med_postnr in (True, False):
            if med_postnr and self._uden_cpradresse:
                continue
            query = self._ejer_query(nu, bfe_nummer, med_postnr)
            resp = self.session.post(
                self.GRAPHQL_URL,
                json={'query': query},
                headers=headers,
                timeout=15,
            )
            self._tjek_svar(resp, 'Opslag af ejeroplysninger (Ejerfortegnelsen)')
            svar = resp.json()
            fejl = svar.get('errors')
            if not fejl:
                data = svar
                break
            # Er cprAdresse ikke aabnet paa den begraensede persontype, saa
            # svarer serveren 'ukendt felt'. Så spoerger vi uden postnummer
            # resten af koerslen i stedet for at fejle paa hver eneste matrikel.
            if med_postnr and self._er_ukendt_felt(fejl):
                self._uden_cpradresse = True
                continue
            raise RuntimeError(f'GraphQL fejl: {fejl[0].get("message", "")}')

        nodes = (data.get('data') or {}).get('EJFCustom_EjerskabBegraenset', {}).get('nodes', [])

        # Vælg den gældende post (filtrer historiske fra)
        gaeldende = [n for n in nodes if n.get('status') == 'gældende']
        if not gaeldende:
            return self._tomt_ejer()

        return self._parse_nodes(gaeldende, only_companies)

    @staticmethod
    def _vejadresse(cpr_adr: dict) -> str:
        """Vej, husnummer, etage og dør som én linje — uden postnr og by.

        Holdes adskilt fra postnummeret, så atlasset kan sætte adressen på
        én linje og postnr. + by på den næste.
        """
        vej = (cpr_adr.get('vejadresseringsnavn') or '').strip()
        if not vej:
            return ''
        husnr = (cpr_adr.get('husnummer') or '').strip()
        linje = ' '.join(p for p in (vej, husnr) if p)
        etage = (cpr_adr.get('etage') or '').strip()
        doer  = (cpr_adr.get('sidedoer') or '').strip()
        if etage or doer:
            sal = ' '.join(p for p in (
                f'{etage}.' if etage else '', doer) if p)
            linje = f'{linje}, {sal}'
        return linje

    def _parse_nodes(self, nodes: list, only_companies: bool) -> dict:
        # Alle gældende ejere (kan være flere ved sameje)
        ejerforhold = str(nodes[0].get('ejerforholdskode') or '')

        navne    = []
        adresser = []
        postnumre = []
        byer      = []
        cvr_numre = []
        adrbeskyt = 'Nej'

        for node in nodes:
            virk = node.get('ejendeVirksomhedCVRNr_20_Virksomhed_CVRNummer_ref')
            if virk:
                cvr  = str(virk.get('CVRNummer', ''))
                navn = (virk.get('id_CVR_Navn_CVREnhedsId_ref') or {}).get('vaerdi', '')
                navne.append(navn)
                cvr_numre.append(cvr)
                continue

            person = node.get('ejendePersonBegraenset')
            if person:
                if only_companies:
                    navne.append('Privat ejer')
                    continue
                navn_obj = person.get('navn') or {}
                navn = navn_obj.get('navn', '') if isinstance(navn_obj, dict) else ''
                navne.append(navn)
                cpr_adr = person.get('cprAdresse') or {}
                adr = self._vejadresse(cpr_adr) or person.get(
                    'standardadresse', '')
                if adr and adr not in adresser:
                    adresser.append(adr)
                postnr = str(cpr_adr.get('postnummer') or '').strip()
                if postnr and postnr not in postnumre:
                    postnumre.append(postnr)
                by = (cpr_adr.get('postdistrikt') or '').strip()
                if by and by not in byer:
                    byer.append(by)
                # Adressebeskyttelse kun ved fuld beskyttelse
                beskyttelser = person.get('beskyttelser') or []
                if any(b.get('beskyttelsestype') == 'adressebeskyttelse' for b in beskyttelser):
                    adrbeskyt = 'Ja'

        antal = len(navne)
        ejernavn = ' / '.join(filter(None, navne))
        if antal > 1:
            ejernavn = f'Sameje ({antal}): {ejernavn}'

        return {
            'ejernavn':           ejernavn,
            'ejeradresse':        ', '.join(adresser),
            'postnr':             ' / '.join(postnumre),
            'postby':             ' / '.join(byer),
            'ejerforhold':        ejerforhold,
            'ejerforhold_tekst':  self.EJERFORHOLD.get(ejerforhold, ejerforhold),
            'cvr_nummer':         ' / '.join(cvr_numre),
            'adressebeskyttelse': adrbeskyt,
        }

    def _tomt_ejer(self) -> dict:
        return {
            'ejernavn':           '',
            'ejeradresse':        '',
            'postnr':             '',
            'postby':             '',
            'ejerforhold':        '',
            'ejerforhold_tekst':  '',
            'cvr_nummer':         '',
            'adressebeskyttelse': '',
        }
