# -*- coding: utf-8 -*-
"""Atlas Mapbook – hovedklasse.

Tilføjer en knap i QGIS' menu/værktøjslinje. Når brugeren klikker:
  1. vises dialogen (lagvalg + felt-mapping),
  2. bygges atlasset ud fra skabelonen via AtlasBuilder,
  3. åbnes layoutet i Layout Designer.
"""

import os

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import QgsProject

from . import faelles_gui
from .dialog import AtlasDialog
from .atlas_builder import AtlasBuilder, AtlasBuildError
from .reference_data import ensure_reference, kategorifelt

PLUGIN_DIR = os.path.dirname(__file__)
TEMPLATE_PATH = os.path.join(PLUGIN_DIR, "resources", "mapbook_skabelon.qpt")
# Referencekortene (arealtabel: Omdrift/Permanent græs) er for store til plugin-
# zippen og downloades fra en GitHub release ved første brug – ét pr. periode,
# som brugeren vælger i dialogen (se reference_data).


class AtlasMapbook:
    """QGIS plugin implementering."""

    def __init__(self, iface):
        self.iface = iface
        self.actions = []

    # ------------------------------------------------------------------ GUI
    def initGui(self):
        icon_path = os.path.join(PLUGIN_DIR, "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        action = QAction(icon, "Lodsejeratlas …", self.iface.mainWindow())
        action.triggered.connect(self.run)
        action.setStatusTip("Generér et mapbook-atlas ud fra et lodsejerlag")

        faelles_gui.tilfoej(self.iface, action)
        self.actions.append(action)

    def unload(self):
        for action in self.actions:
            faelles_gui.fjern(self.iface, action)
        self.actions = []

    # ------------------------------------------------------------------ run
    def run(self):
        """Vis dialogen og byg atlasset hvis brugeren bekræfter."""
        if not os.path.exists(TEMPLATE_PATH):
            QMessageBox.critical(
                self.iface.mainWindow(),
                "Atlas Mapbook",
                "Skabelonen blev ikke fundet:\n{}".format(TEMPLATE_PATH),
            )
            return

        dialog = AtlasDialog(self.iface, parent=self.iface.mainWindow())
        if not dialog.exec_():
            return  # brugeren annullerede

        result = dialog.result()  # AtlasDialogResult
        layer = result.layer

        # Referencekortet for den valgte periode downloades fra release ved
        # første brug (caches lokalt, ét kort pr. periode).
        periode = result.reference_periode
        reference_path = ensure_reference(self.iface.mainWindow(), periode)
        if reference_path is None:
            return  # bruger annullerede download eller fejl (allerede vist)

        try:
            builder = AtlasBuilder(
                project=QgsProject.instance(),
                template_path=TEMPLATE_PATH,
                iface=self.iface,
                matrikel_kant=result.matrikel_kant,
                matrikel_fyld=result.matrikel_fyld,
                omraade_kant=result.omraade_kant,
            )
            layout = builder.build(
                coverage_layer=layer,
                field_mapping=result.field_mapping,
                generate_lobenr=result.generate_lobenr,
                generate_postnr=result.generate_postnr,
                layout_name=result.layout_name,
                owner_field=result.owner_field,
                project_area_layer=result.project_area_layer,
                background_auto=result.background_auto,
                background_layer=result.background_layer,
                reference_path=reference_path,
                reference_field=kategorifelt(periode),
                reference_years=periode,
                min_area_m2=result.min_area_m2,
                extra_layers=result.extra_layers,
            )
        except AtlasBuildError as exc:
            QMessageBox.critical(
                self.iface.mainWindow(), "Atlas Mapbook", str(exc)
            )
            return
        except Exception as exc:  # pragma: no cover - sikkerhedsnet
            QMessageBox.critical(
                self.iface.mainWindow(),
                "Atlas Mapbook",
                "Uventet fejl under opbygning af atlas:\n{}".format(exc),
            )
            return

        # Start atlas-preview på første ejer, så hovedkortet straks zoomer
        # korrekt (ellers viser det skabelonens gamle extent indtil brugeren
        # selv slår preview til).
        atlas = layout.atlas()
        try:
            atlas.beginRender()
            atlas.first()
        except Exception:
            pass

        # Åbn layoutet i Layout Designer, klar til brug.
        self.iface.openLayoutDesigner(layout)

        page_count = atlas.count()
        self.iface.messageBar().pushSuccess(
            "Atlas Mapbook",
            "Atlasset '{}' er klar – {} sider (ejere).".format(
                result.layout_name, page_count
            ),
        )
