import time
import requests
from datetime import datetime, timezone
from xml.etree import ElementTree as ET
from qgis.core import QgsGeometry

# OAuth-token cache: {client_id: {'token': str, 'expires': float}}
_token_cache: dict[str, dict] = {}


class AdgangAfvist(RuntimeError):
    """Datafordeleren afviste opslaget — det er adgangen, ikke dataen."""


class DatafordelerClient:
    """Geometri og ejeroplysninger via Datafordeleren (OAuth Shared Secret)."""

    WFS_URL = 'https://wfs.datafordeler.dk/MATRIKLEN2/MatGaeldendeOgForeloebigWFS/1.0.0/WFS'

    # Ejerforholdskoder efter den fælles grunddata-kodeliste (ESR-afledt,
    # samme liste som BBR bruger — se teknik.bbr.dk/kodelister). Teksterne
    # er de officielle; kun 90 er forkortet, da den fylder 140 tegn.
    #
    # Fem af koderne var tidligere forkerte: 20 og 30 var byttet om (alment
    # boligselskab kaldtes aktieselskab), og 60 og 80 var byttet om (anden
    # kommune kaldtes staten). 41 manglede, og 90 blev kaldt "anden
    # offentlig ejer", selvom den netop dækker blandet og privat ejerskab.
    EJERFORHOLD = {
        '10': 'Privatpersoner eller interessentskab',
        '20': 'Alment boligselskab',
        '30': 'Aktie-, anpart- eller andet selskab (undtagen interessentskab)',
        '40': 'Forening, legat eller selvejende institution',
        '41': 'Privat andelsboligforening',
        '50': 'Den kommune, hvori ejendommen er beliggende',
        '60': 'Anden primærkommune',
        '70': 'Region',
        '80': 'Staten',
        '90': 'Andet, herunder moderejendomme og ejendomme med flere '
              'kategorier af ejere',
        '99': 'Ikke beregnet',
    }

    TOKEN_URL   = 'https://auth.datafordeler.dk/realms/distribution/protocol/openid-connect/token'
    GRAPHQL_URL = 'https://graphql.datafordeler.dk/flexibleCurrent/v1/'

    def __init__(self, client_id: str, client_secret: str, wfs_apikey: str):
        self._client_id     = client_id
        self._client_secret = client_secret
        self._wfs_apikey    = wfs_apikey
        self.session = requests.Session()
        self.session.headers['User-Agent'] = (
            'Lodsejere QGIS Plugin / Limfjordssekretariatet'
        )
        #: Sat hvis serveren afviser cprAdresse-feltet — så spørges der uden
        #: personens postnummer resten af kørslen (se get_ejer).
        self._uden_cpradresse = False
        #: Hvilken form virksomhedens adresse-join skal have. Se
        #: VIRK_ADRESSE_FORMER; skrues ned ét trin ad gangen, hvis
        #: serveren afviser den.
        self._virk_adresse_form = 0
        #: Hvilket navn CPR-nøglen og person-joinet har i det fortrolige
        #: ejerskab. Se CPR_FELTER og PERSON_JOIN_FORTROLIG.
        self._cpr_felt_form = 0
        self._person_join_form = 0

    # ------------------------------------------------------------------
    # Fejlhåndtering
    # ------------------------------------------------------------------

    @staticmethod
    def _fejltekst(resp) -> str:
        """Den forklarende del af svaret, uden JSON-støj og trace-id.

        Datafordelerens GraphQL svarer med en errors-liste, hvor hver fejl
        har sit eget traceId. Tages hele kroppen med, bliver ellers ens
        fejl unikke, og otte afviste opslag ser ud som otte forskellige
        problemer. Her tages kun beskeden, fejlkoden og den ressource der
        blev afvist.
        """
        try:
            data = resp.json()
        except ValueError:
            return ' '.join((resp.text or '').split())[:300]
        if not isinstance(data, dict):
            return ' '.join((resp.text or '').split())[:300]

        fejl = (data.get('errors') or [{}])[0]
        dele = [fejl.get('message') or '']
        kode = (fejl.get('extensions') or {}).get('code')
        if kode:
            dele.append(f'kode {kode}')
        sti = fejl.get('path') or []
        if sti:
            dele.append('ressource: ' + ', '.join(str(s) for s in sti))
        tekst = ' — '.join(d for d in dele if d)
        return tekst or ' '.join((resp.text or '').split())[:300]

    @classmethod
    def _tjek_svar(cls, resp, hvad: str) -> None:
        """Rejs en fejl der siger HVORFOR, ikke bare hvilken statuskode.

        requests' raise_for_status() giver kun "403 Client Error: Forbidden
        for url: ...". Datafordeleren skriver som regel årsagen i svarets
        krop, og uden den står brugeren uden noget at handle på.
        """
        if resp.ok:
            return
        krop = cls._fejltekst(resp)
        besked = f'{hvad} fejlede: HTTP {resp.status_code}'
        if krop:
            besked += f' — {krop}'
        if resp.status_code in (401, 403):
            raise AdgangAfvist(besked + cls.AFVIST_FORKLARING)
        raise RuntimeError(besked)

    AFVIST_FORKLARING = (
        '\n\nAdgangen blev afvist, selvom log ind lykkedes. Nævnes '
        'en ressource ovenfor, er det præcis den entitet, jeres '
        'ansøgning om dataadgang skal omfatte — se Datafordeler '
        'Administration → Dataadgang, hvor status skal stå som '
        '"Godkendt". Fejlkoden DAF-AUTH-0001 betyder netop det. '
        'Dækker ansøgningen kun virksomhedsdata, kan pluginnet '
        'stadig bruges med "Vis kun virksomhedsejere" — adgang til '
        'personoplysninger godkendes særskilt.'
    )

    CPR_FORKLARING = (
        '\n\nCPR-numre ligger i Ejerfortegnelsen Fortrolig (entiteten '
        'EJF_Ejerskab), som kun offentlige myndigheder kan få adgang til. '
        'Fjern fluebenet "Hent CPR-numre", eller søg om adgangen under '
        'Dataadgang i Datafordeler Administration.'
    )

    # ------------------------------------------------------------------
    # OAuth
    # ------------------------------------------------------------------

    def _get_token(self) -> str:
        cached = _token_cache.get(self._client_id)
        if cached and cached['expires'] > time.time() + 30:
            return cached['token']

        resp = self.session.post(
            self.TOKEN_URL,
            data={
                'grant_type':    'client_credentials',
                'client_id':     self._client_id,
                'client_secret': self._client_secret,
            },
            timeout=15,
        )
        self._tjek_svar(resp, 'Log ind på Datafordeleren')
        data       = resp.json()
        token      = data['access_token']
        expires_in = int(data.get('expires_in', 3600))
        _token_cache[self._client_id] = {
            'token':   token,
            'expires': time.time() + expires_in,
        }
        return token

    # ------------------------------------------------------------------
    # Matrikler (WFS)
    # ------------------------------------------------------------------

    @staticmethod
    def _poslist_to_wkt_ring(poslist_text: str) -> str:
        coords = poslist_text.split()
        pairs  = [f'{coords[i]} {coords[i+1]}' for i in range(0, len(coords) - 1, 2)]
        return '(' + ', '.join(pairs) + ')'

    def _gml_surface_to_wkt(self, geometri_el) -> str:
        # Håndterer gml:Polygon og gml:MultiSurface/gml:Surface
        rings = []
        for poslist in geometri_el.iter('{http://www.opengis.net/gml/3.2}posList'):
            rings.append(self._poslist_to_wkt_ring(poslist.text.strip()))
        if not rings:
            return ''
        # Første ring = ydre, resten = huller
        return 'POLYGON(' + ', '.join(rings) + ')'

    NS = {
        'wfs': 'http://www.opengis.net/wfs/2.0',
        'mat': 'http://data.gov.dk/schemas/matrikel/1',
        'gml': 'http://www.opengis.net/gml/3.2',
    }

    def get_jordstykker(self, geometry) -> list[dict]:
        bb   = geometry.boundingBox()
        bbox = f'{bb.xMinimum()},{bb.yMinimum()},{bb.xMaximum()},{bb.yMaximum()},EPSG:25832'

        start_index = 0
        page_size   = 500
        all_features = []

        while True:
            resp = self.session.get(
                self.WFS_URL,
                params={
                    'SERVICE':    'WFS',
                    'REQUEST':    'GetFeature',
                    'VERSION':    '2.0.0',
                    'TYPENAMES':  'mat:Jordstykke_Gaeldende',
                    'BBOX':       bbox,
                    'COUNT':      page_size,
                    'STARTINDEX': start_index,
                    'apikey':     self._wfs_apikey,
                },
                timeout=60,
            )
            self._tjek_svar(resp, 'Opslag af matrikler (Matriklen WFS)')

            root    = ET.fromstring(resp.content)
            members = root.findall('wfs:member', self.NS)
            all_features.extend(members)

            matched   = int(root.get('numberMatched', '0') or '0')
            returned  = int(root.get('numberReturned', '0') or '0')
            start_index += returned
            if start_index >= matched or returned == 0:
                break

        results = []
        for member in all_features:
            js = member.find('mat:Jordstykke_Gaeldende', self.NS)
            if js is None:
                continue

            gml_geom = js.find('mat:geometri', self.NS)
            if gml_geom is None:
                continue

            def txt(tag):
                el = js.find(f'mat:{tag}', self.NS)
                return el.text if el is not None and el.text else ''

            geom_wkt = self._gml_surface_to_wkt(gml_geom)

            bfe_raw = txt('samletFastEjendomLokalId')
            bfe     = str(int(bfe_raw)) if bfe_raw else ''

            results.append({
                'geometri_wkt':   geom_wkt,
                'ejerlavskode':   int(txt('ejerlavskode') or 0),
                'ejerlavsnavn':   '',
                'matrikelnummer': txt('matrikelnummer'),
                'bfe_nummer':     bfe,
            })
        return results

    # ------------------------------------------------------------------
    # Ejeroplysninger — EJF GraphQL
    # ------------------------------------------------------------------

    #: Adressen på ejeren ligger i cprAdresse — standardadresse alene er
    #: kun vej og husnummer, uden postnummer og by. Feltnavnene følger
    #: Datafordelerens transitionsguide for EJF.
    CPR_ADRESSE = """
                        cprAdresse {
                            vejadresseringsnavn
                            husnummer
                            etage
                            sidedoer
                            postnummer
                            postdistrikt
                        }"""

    #: Virksomhedens adresse hentes gennem CVR-joinet. Feltnavnene og
    #: filteret på "beliggenhedsadresse" følger Datafordelerens
    #: transitionsguide (afsnit 4.4.2).
    VIRK_ADRESSE_FELTER = """
                                AdresseringAnvendelse
                                Adresse
                                CVRAdresse_vejnavn
                                CVRAdresse_husnummerFra
                                CVRAdresse_etagebetegnelse
                                CVRAdresse_doerbetegnelse
                                CVRAdresse_postnummer
                                CVRAdresse_postdistrikt"""

    #: To former af det samme join. Guiden viser den første; den anden er
    #: den flade form, som navne-joinet allerede bruger i praksis. Kan
    #: serveren ingen af dem, spørges der slet ikke om adressen.
    VIRK_ADRESSE_FORMER = (
        """
                        id_CVR_Adressering_CVREnhedsId_ref(
                            where: {{ AdresseringAnvendelse: {{
                                eq: "beliggenhedsadresse" }} }}
                        ) {{
                            nodes {{{felter}
                            }}
                        }}""",
        """
                        id_CVR_Adressering_CVREnhedsId_ref {{{felter}
                        }}""",
        "",
    )

    #: CPR-numre findes kun i det fortrolige ejerskab. Det begrænsede, som
    #: bruges ellers, har hverken CPR-nøglen eller adgang til at få den.
    ROD_BEGRAENSET = 'EJFCustom_EjerskabBegraenset'
    ROD_FORTROLIG = 'EJF_Ejerskab'

    #: CPR-nøglen på ejerskabet. Datafordelerens transitionsguide skriver
    #: den begge veje (afsnit 4.4.3 og 4.4.4); navnet følger ellers mønstret
    #: fra ejendeVirksomhedCVRNr. Den første serveren kender, bruges.
    CPR_FELTER = ('ejendePersonPersonNr', 'ejendePersonPersonNR')

    #: Personen bag CPR-nøglen. Det begrænsede join udelader beskyttede
    #: navne og adresser — det svarer til niveauet Fortrolig. ejendePerson
    #: er guidens eksempel, men kan kræve Fortrolig Beskyttet.
    PERSON_JOIN_FORTROLIG = ('ejendePersonBegraenset', 'ejendePerson')

    @staticmethod
    def _klager_over(fejl: list, navn: str) -> bool:
        """Klager GraphQL over et felt vi har spurgt om, frem for om data?

        Datafordeleren svarer fx "Unknown field 'cprAdresse' on type ...".
        Nævnes feltet i beskeden, er det vores forespørgsel den er gal
        med — ikke adgangen eller dataen.
        """
        navn = navn.lower()
        for f in fejl or []:
            besked = (f.get('message') or '').lower()
            if navn in besked:
                return True
            sti = [str(p).lower() for p in (f.get('path') or [])]
            if any(navn in p for p in sti) and (
                    'unknown' in besked or 'ukendt' in besked
                    or 'does not exist' in besked or 'findes ikke' in besked):
                return True
        return False

    def _skru_ned(self, fejl: list, med_cpr: bool = False) -> bool:
        """Sluk den del af forespørgslen serveren ikke vil svare på.

        Returnerer True hvis der blev skruet ned, så opslaget kan prøves
        igen. Valget huskes resten af kørslen — ellers ville hver eneste
        matrikel koste et spildt opslag.
        """
        if med_cpr:
            # CPR-nøglen først: dens navn indeholder person-joinets.
            felt = self.CPR_FELTER[self._cpr_felt_form]
            if (self._cpr_felt_form + 1 < len(self.CPR_FELTER)
                    and self._klager_over(fejl, felt)):
                self._cpr_felt_form += 1
                return True
            join = self.PERSON_JOIN_FORTROLIG[self._person_join_form]
            if (self._person_join_form + 1 < len(self.PERSON_JOIN_FORTROLIG)
                    and self._klager_over(fejl, join)):
                self._person_join_form += 1
                return True
        if not self._uden_cpradresse and self._klager_over(fejl, 'cpradresse'):
            self._uden_cpradresse = True
            return True
        naeste = self._virk_adresse_form + 1
        if naeste < len(self.VIRK_ADRESSE_FORMER) and self._klager_over(
                fejl, 'adressering'):
            self._virk_adresse_form = naeste
            return True
        return False

    def _rod_og_person(self, med_cpr: bool):
        """(rodentitet, person-join, CPR-felt eller '') for opslaget."""
        if not med_cpr:
            return self.ROD_BEGRAENSET, 'ejendePersonBegraenset', ''
        return (self.ROD_FORTROLIG,
                self.PERSON_JOIN_FORTROLIG[self._person_join_form],
                self.CPR_FELTER[self._cpr_felt_form])

    def _ejer_query(self, nu: str, bfe_nummer: str,
                    med_cpr: bool = False) -> str:
        virk_adresse = self.VIRK_ADRESSE_FORMER[self._virk_adresse_form]
        if virk_adresse:
            virk_adresse = virk_adresse.format(felter=self.VIRK_ADRESSE_FELTER)
        rod, person, cpr_felt = self._rod_og_person(med_cpr)
        return """
        query {
            %s(
                virkningstid: "%s"
                where: { bestemtFastEjendomBFENr: { eq: %s } }
            ) {
                nodes {
                    bestemtFastEjendomBFENr
                    ejerforholdskode
                    status%s
                    ejendeVirksomhedCVRNr_20_Virksomhed_CVRNummer_ref {
                        CVRNummer
                        id_CVR_Navn_CVREnhedsId_ref { vaerdi }%s
                    }
                    %s {
                        navn { navn }
                        standardadresse%s
                        beskyttelser { beskyttelsestype }
                        status
                    }
                }
            }
        }
        """ % (rod, nu, bfe_nummer,
               ('\n                    ' + cpr_felt) if cpr_felt else '',
               virk_adresse, person,
               '' if self._uden_cpradresse else self.CPR_ADRESSE)

    def get_ejer(self, bfe_nummer: str, only_companies: bool = True,
                 med_cpr: bool = False) -> dict:
        """Ejeroplysninger for én ejendom.

        med_cpr henter også ejernes CPR-numre fra Ejerfortegnelsen Fortrolig.
        Det kræver en godkendt adgang, som kun offentlige myndigheder kan få;
        afvises den, rejses AdgangAfvist.
        """
        if not bfe_nummer:
            return self._tomt_ejer()
        # Vises private ejere ikke, er der ingen CPR-numre at hente.
        med_cpr = med_cpr and not only_companies

        token = self._get_token()
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type':  'application/json',
        }

        nu = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S+00:00')

        # Adressefelterne er ikke nødvendigvis åbne på alle adgange. Er de
        # ikke, svarer serveren 'ukendt felt' — så slukkes den del af
        # forespørgslen, og opslaget prøves igen. Højst ét forsøg pr. del,
        # og valget huskes resten af kørslen.
        data = None
        forsoeg = (len(self.VIRK_ADRESSE_FORMER) + len(self.CPR_FELTER)
                   + len(self.PERSON_JOIN_FORTROLIG) + 2)
        for _ in range(forsoeg):
            query = self._ejer_query(nu, bfe_nummer, med_cpr)
            resp = self.session.post(
                self.GRAPHQL_URL,
                json={'query': query},
                headers=headers,
                timeout=15,
            )
            try:
                self._tjek_svar(
                    resp, 'Opslag af ejeroplysninger (Ejerfortegnelsen)')
            except AdgangAfvist as e:
                raise AdgangAfvist(
                    str(e) + (self.CPR_FORKLARING if med_cpr else '')) from None
            svar = resp.json()
            fejl = svar.get('errors')
            if not fejl:
                data = svar
                break
            if self._skru_ned(fejl, med_cpr):
                continue
            if any((f.get('extensions') or {}).get('code') == 'DAF-AUTH-0001'
                   for f in fejl):
                raise AdgangAfvist(
                    'Opslag af ejeroplysninger (Ejerfortegnelsen) blev afvist — '
                    + self._fejltekst(resp) + self.AFVIST_FORKLARING
                    + (self.CPR_FORKLARING if med_cpr else ''))
            raise RuntimeError(f'GraphQL fejl: {fejl[0].get("message", "")}')
        if data is None:
            raise RuntimeError(
                'Ejerfortegnelsen svarede ikke på opslaget af ejeroplysninger.')

        rod, person, cpr_felt = self._rod_og_person(med_cpr)
        nodes = ((data.get('data') or {}).get(rod) or {}).get('nodes') or []

        # Vælg den gældende post (filtrer historiske fra)
        gaeldende = [n for n in nodes if n.get('status') == 'gældende']
        if not gaeldende:
            return self._tomt_ejer()

        return self._parse_nodes(gaeldende, only_companies, person, cpr_felt)

    @staticmethod
    def _cpr_tekst(vaerdi) -> str:
        """CPR-nummeret som ti cifre — også hvis det kommer som et tal.

        Som tal mister et CPR-nummer født den 1.-9. i måneden sit første nul.
        """
        if vaerdi is None:
            return ''
        tekst = str(vaerdi).strip()
        if isinstance(vaerdi, int) or (tekst.isdigit() and len(tekst) < 10):
            tekst = tekst.zfill(10)
        return tekst

    @staticmethod
    def _joinraekker(vaerdi) -> list:
        """Raekkerne i et CVR-join, uanset om svaret er fladt eller pakket.

        Joinet svarer enten med selve raekken, med en liste, eller med en
        connection ({nodes: [...]}) alt efter hvilken form forespoergslen
        brugte. Her haandteres alle tre, saa laesningen ikke afhaenger af
        hvilken form serveren tog imod.
        """
        if not vaerdi:
            return []
        if isinstance(vaerdi, list):
            return [r for r in vaerdi if isinstance(r, dict)]
        if isinstance(vaerdi, dict):
            if 'nodes' in vaerdi:
                return [r for r in (vaerdi.get('nodes') or [])
                        if isinstance(r, dict)]
            return [vaerdi]
        return []

    @classmethod
    def _virksomhedsnavn(cls, virk: dict) -> str:
        raekker = cls._joinraekker(virk.get('id_CVR_Navn_CVREnhedsId_ref'))
        for r in raekker:
            navn = (r.get('vaerdi') or '').strip()
            if navn:
                return navn
        return ''

    @classmethod
    def _virksomhedsadresse(cls, virk: dict):
        """Virksomhedens beliggenhedsadresse: (vejlinje, postnr, by).

        Har virksomheden flere adresser, foretraekkes beliggenhedsadressen
        - ellers tages den foerste. Vejlinjen holdes fri for postnummer og
        by, praecis som for personejere, saa atlassets to linjer passer.
        """
        raekker = cls._joinraekker(
            virk.get('id_CVR_Adressering_CVREnhedsId_ref'))
        if not raekker:
            return '', '', ''
        valgt = raekker[0]
        for r in raekker:
            if (r.get('AdresseringAnvendelse') or '') == 'beliggenhedsadresse':
                valgt = r
                break

        vej   = (valgt.get('CVRAdresse_vejnavn') or '').strip()
        husnr = (valgt.get('CVRAdresse_husnummerFra') or '').strip()
        etage = (valgt.get('CVRAdresse_etagebetegnelse') or '').strip()
        doer  = (valgt.get('CVRAdresse_doerbetegnelse') or '').strip()
        linje = ' '.join(p for p in (vej, husnr) if p)
        if linje and (etage or doer):
            sal = ' '.join(p for p in (
                f'{etage}.' if etage else '', doer) if p)
            linje = f'{linje}, {sal}'
        if not linje:
            # Nogle virksomheder har kun adressen som fritekst eller postboks.
            linje = (valgt.get('Adresse')
                     or valgt.get('CVRAdresse_adresseFritekst') or '').strip()

        postnr = str(valgt.get('CVRAdresse_postnummer') or '').strip()
        by     = (valgt.get('CVRAdresse_postdistrikt') or '').strip()
        return linje, postnr, by

    @staticmethod
    def _vejadresse(cpr_adr: dict) -> str:
        """Vej, husnummer, etage og dør som én linje — uden postnr og by.

        Holdes adskilt fra postnummeret, så atlasset kan sætte adressen på
        én linje og postnr. + by på den næste.
        """
        vej = (cpr_adr.get('vejadresseringsnavn') or '').strip()
        if not vej:
            return ''
        husnr = (cpr_adr.get('husnummer') or '').strip()
        linje = ' '.join(p for p in (vej, husnr) if p)
        etage = (cpr_adr.get('etage') or '').strip()
        doer  = (cpr_adr.get('sidedoer') or '').strip()
        if etage or doer:
            sal = ' '.join(p for p in (
                f'{etage}.' if etage else '', doer) if p)
            linje = f'{linje}, {sal}'
        return linje

    def _parse_nodes(self, nodes: list, only_companies: bool,
                     person_join: str = 'ejendePersonBegraenset',
                     cpr_felt: str = '') -> dict:
        # Alle gældende ejere (kan være flere ved sameje)
        ejerforhold = str(nodes[0].get('ejerforholdskode') or '')

        navne    = []
        adresser = []
        postnumre = []
        byer      = []
        cvr_numre = []
        cpr_numre = []
        adrbeskyt = 'Nej'

        for node in nodes:
            virk = node.get('ejendeVirksomhedCVRNr_20_Virksomhed_CVRNummer_ref')
            if virk:
                cvr  = str(virk.get('CVRNummer', ''))
                navn = self._virksomhedsnavn(virk)
                navne.append(navn)
                cvr_numre.append(cvr)
                adr, postnr, by = self._virksomhedsadresse(virk)
                if adr and adr not in adresser:
                    adresser.append(adr)
                if postnr and postnr not in postnumre:
                    postnumre.append(postnr)
                if by and by not in byer:
                    byer.append(by)
                continue

            person = node.get(person_join)
            cpr = self._cpr_tekst(node.get(cpr_felt)) if cpr_felt else ''
            if person or cpr:
                person = person or {}
                if only_companies:
                    navne.append('Privat ejer')
                    continue
                # Samme rækkefølge som navnene, så sameje kan læses parvis.
                cpr_numre.append(cpr or '?')
                navn_obj = person.get('navn') or {}
                navn = navn_obj.get('navn', '') if isinstance(navn_obj, dict) else ''
                navne.append(navn)
                cpr_adr = person.get('cprAdresse') or {}
                adr = self._vejadresse(cpr_adr) or person.get(
                    'standardadresse', '')
                if adr and adr not in adresser:
                    adresser.append(adr)
                postnr = str(cpr_adr.get('postnummer') or '').strip()
                if postnr and postnr not in postnumre:
                    postnumre.append(postnr)
                by = (cpr_adr.get('postdistrikt') or '').strip()
                if by and by not in byer:
                    byer.append(by)
                # Adressebeskyttelse kun ved fuld beskyttelse
                beskyttelser = person.get('beskyttelser') or []
                if any(b.get('beskyttelsestype') == 'adressebeskyttelse' for b in beskyttelser):
                    adrbeskyt = 'Ja'

        antal = len(navne)
        ejernavn = ' / '.join(filter(None, navne))
        if antal > 1:
            ejernavn = f'Sameje ({antal}): {ejernavn}'

        return {
            'ejernavn':           ejernavn,
            'ejeradresse':        ', '.join(adresser),
            'postnr':             ' / '.join(postnumre),
            'postby':             ' / '.join(byer),
            'ejerforhold':        ejerforhold,
            'ejerforhold_tekst':  self.EJERFORHOLD.get(ejerforhold, ejerforhold),
            'cvr_nummer':         ' / '.join(cvr_numre),
            'cpr_nummer':         (' / '.join(cpr_numre)
                                   if cpr_felt and any(c != '?' for c in cpr_numre)
                                   else ''),
            'adressebeskyttelse': adrbeskyt,
        }

    def _tomt_ejer(self) -> dict:
        return {
            'ejernavn':           '',
            'ejeradresse':        '',
            'postnr':             '',
            'postby':             '',
            'ejerforhold':        '',
            'ejerforhold_tekst':  '',
            'cvr_nummer':         '',
            'cpr_nummer':         '',
            'adressebeskyttelse': '',
        }
