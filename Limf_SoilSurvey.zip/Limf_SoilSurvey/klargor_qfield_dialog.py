import os
from qgis.PyQt import uic, QtWidgets
from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtWidgets import QMessageBox, QTableWidgetItem, QHeaderView
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    Qgis,
    QgsProject, QgsField, QgsWkbTypes,
    QgsEditorWidgetSetup, QgsDefaultValue,
    QgsCategorizedSymbolRenderer,
    QgsRendererCategory,
    QgsFillSymbol,
    QgsMarkerSymbol,
    QgsMapLayer,
    QgsPalLayerSettings,
    QgsTextBufferSettings,
    QgsTextFormat,
    QgsVectorLayerSimpleLabeling,
)

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'klargor_qfield_dialog.ui'))

STATUS_FIELD = 'status'
VAL_IKKE = 'Ikke-udtaget'
VAL_UDTAGET = 'Udtaget'

JORDTYPE_VALG = [
    'Uomsat tørv',
    'Svagt omsat tørv',  
    'Moderat omsat tørv',
    'Stærkt omsat tørv',
    'Fuldstændig omsat tørv',
    'Finkornet sand',
    'Mellemkornet sand',
    'Mellemkornet sand med indslag af omsat tørv',
    'Grovkornet sand',
    'Groft og fint grus',
    'Ler',
    'Silt',    
    'Kalkgytje',
]

# (feltnavn, type, alias, widget-type, widget-config)
STANDARD_FIELDS = [
    ('status',      QVariant.String,  'Status',          'ValueMap',        {'map': [{VAL_IKKE: VAL_IKKE}, {VAL_UDTAGET: VAL_UDTAGET}]}),
    ('Vol.lgd',     QVariant.Double,  'Volumen lgd (cm)',     'TextEdit',        {}),
    ('VSP',         QVariant.Double,  'Vandspejl (cm)',       'TextEdit',        {}),
    ('Foto',        QVariant.String,  'Foto af prøve',   'ExternalResource', {'StorageType': '0', 'DocumentViewer': '0', 'FileWidget': '1', 'FileWidgetButton': '1'}),
    ('lag 1',       QVariant.String,  'Lag 1 (cm)',      'TextEdit',        {}),
    ('lag 1 type',  QVariant.String,  'Lag 1 jordtype',  'ValueMap',        {'map': [{v: v} for v in JORDTYPE_VALG]}),
    ('lag 2',       QVariant.String,  'Lag 2 (cm)',      'TextEdit',        {}),
    ('lag 2 type',  QVariant.String,  'Lag 2 jordtype',  'ValueMap',        {'map': [{v: v} for v in JORDTYPE_VALG]}),
    ('lag 3',       QVariant.String,  'Lag 3 (cm)',      'TextEdit',        {}),
    ('lag 3 type',  QVariant.String,  'Lag 3 jordtype',  'ValueMap',        {'map': [{v: v} for v in JORDTYPE_VALG]}),
    ('lag 4',       QVariant.String,  'Lag 4 (cm)',      'TextEdit',        {}),
    ('lag 4 type',  QVariant.String,  'Lag 4 jordtype',  'ValueMap',        {'map': [{v: v} for v in JORDTYPE_VALG]}),
    ('lag 5',       QVariant.String,  'Lag 5 (cm)',      'TextEdit',        {}),
    ('lag 5 type',  QVariant.String,  'Lag 5 jordtype',  'ValueMap',        {'map': [{v: v} for v in JORDTYPE_VALG]}),
    # Begge bemærkningsfelter er flerlinjede (IsMultiline), så der er plads
    # til at skrive i QField i stedet for én smal linje.
    ('comment',     QVariant.String,  'Kommentar',       'TextEdit',        {'IsMultiline': True}),
    # 'intern' kommer IKKE på rapporten: eksporter_rapport_dialog plukker
    # felterne ved navn (lag 1-5, comment, Vol.lgd, Perm., VSP, Foto), og
    # 'intern' står ikke på listen. Her kan man skrive til sig selv.
    ('intern',      QVariant.String,  'Intern bemærkning (ikke i rapport)', 'TextEdit', {'IsMultiline': True}),
]

STANDARD_NAMES = {f[0] for f in STANDARD_FIELDS}

#: Markerer en tabelrække for et standardfelt laget endnu ikke har. Feltet
#: tilføjes først når man trykker Kør — se _load_fields().
MANGLER = -1

#: Feltet der skrives som label på prøvepunkterne — grid-nummeret.
LABEL_FIELD = 'id'


from . import faelles_ui


class KlargorQFieldDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        faelles_ui.anvend_stil(self)
        self._populate_lag()
        self.cboLag.currentIndexChanged.connect(self._load_fields)
        self.btnKor.clicked.connect(self.kor)

        # Kolonnebredder
        hdr = self.tblFelter.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)

        if self.cboLag.count():
            self._load_fields()

    def _populate_lag(self):
        self.cboLag.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == layer.VectorLayer:
                if layer.geometryType() in (QgsWkbTypes.PolygonGeometry, QgsWkbTypes.PointGeometry):
                    self.cboLag.addItem(layer.name(), layer.id())

    def _current_layer(self):
        layer_id = self.cboLag.currentData()
        return QgsProject.instance().mapLayer(layer_id) if layer_id else None

    def _load_fields(self):
        """Vis lagets felter. LÆSER KUN — laget må ikke ændres herfra.

        Funktionen kører både når dialogen åbner og hver gang man skifter lag
        i rullelisten. Tilføjede den felter (som den gjorde før), blev laget
        ændret uden at nogen havde trykket på Kør — og et kig i rullelisten
        ændrede hvert lag man kiggede på. Manglende standardfelter vises
        derfor blot som kursive rækker; de oprettes i kor().
        """
        layer = self._current_layer()
        if not layer:
            self.tblFelter.setRowCount(0)
            return

        # Byg tabellen
        form_cfg = layer.editFormConfig()
        fields = layer.fields()
        mangler = [s for s in STANDARD_FIELDS if fields.indexOf(s[0]) < 0]
        self.tblFelter.setRowCount(fields.count() + len(mangler))

        for row in range(fields.count()):
            field = fields.field(row)
            name = field.name()
            alias = field.alias() or name
            is_standard = name in STANDARD_NAMES

            # Feltnavn (ikke redigerbar). Feltindekset gemmes paa raekken, saa
            # kor() ikke behoever at regne med at raekke == feltindeks — det
            # holder ikke, naar der ligger raekker for felter laget ikke har.
            name_item = QTableWidgetItem(name)
            name_item.setFlags(Qt.ItemFlag.ItemIsEnabled)
            name_item.setData(Qt.ItemDataRole.UserRole, row)
            if is_standard:
                font = name_item.font()
                font.setBold(True)
                name_item.setFont(font)
            self.tblFelter.setItem(row, 0, name_item)

            # Alias (redigerbar)
            alias_item = QTableWidgetItem(alias)
            self.tblFelter.setItem(row, 1, alias_item)

            # Medtages: felt er ikke skjult
            included = layer.editorWidgetSetup(row).type() != 'Hidden'
            chk_med = QTableWidgetItem()
            chk_med.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            chk_med.setCheckState(Qt.CheckState.Checked if included else Qt.CheckState.Unchecked)
            chk_med.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.tblFelter.setItem(row, 2, chk_med)

            # Redigerbar: felt er ikke read-only
            editable = not form_cfg.readOnly(row)
            chk_red = QTableWidgetItem()
            chk_red.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            chk_red.setCheckState(Qt.CheckState.Checked if editable else Qt.CheckState.Unchecked)
            chk_red.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.tblFelter.setItem(row, 3, chk_red)

        # Standardfelter laget mangler: vist i kursiv som "tilfoejes naar du
        # trykker Koer". Fjern fluebenet i Medtages, hvis et af dem ikke skal
        # oprettes.
        for i, (navn, _vtype, alias, _w, _c) in enumerate(mangler):
            row = fields.count() + i
            name_item = QTableWidgetItem(navn)
            name_item.setFlags(Qt.ItemFlag.ItemIsEnabled)
            name_item.setData(Qt.ItemDataRole.UserRole, MANGLER)
            font = name_item.font()
            font.setBold(True)
            font.setItalic(True)
            name_item.setFont(font)
            name_item.setToolTip(
                'Standardfeltet mangler i laget. Det oprettes, når du '
                'trykker Kør — ikke før.')
            self.tblFelter.setItem(row, 0, name_item)

            alias_item = QTableWidgetItem(alias)
            self.tblFelter.setItem(row, 1, alias_item)

            for col in (2, 3):
                chk = QTableWidgetItem()
                chk.setFlags(Qt.ItemFlag.ItemIsEnabled
                             | Qt.ItemFlag.ItemIsUserCheckable)
                chk.setCheckState(Qt.CheckState.Checked)
                chk.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.tblFelter.setItem(row, col, chk)

    def _opret_manglende_felter(self, layer):
        """Opret de afkrydsede standardfelter laget mangler. -> True hvis ok.

        Her — og kun her — ændres lagets skema. Kaldes fra kor().
        """
        nye = []
        for row in range(self.tblFelter.rowCount()):
            navn_item = self.tblFelter.item(row, 0)
            if navn_item is None or navn_item.data(
                    Qt.ItemDataRole.UserRole) != MANGLER:
                continue
            if self.tblFelter.item(row, 2).checkState() != Qt.CheckState.Checked:
                continue    # fravalgt — opret det slet ikke
            std = next((s for s in STANDARD_FIELDS
                        if s[0] == navn_item.text()), None)
            if std is None:
                continue
            f = QgsField(std[0], std[1])
            f.setAlias(std[2])
            nye.append(f)
        if not nye:
            return True
        layer.startEditing()
        for f in nye:
            layer.addAttribute(f)
        if not layer.commitChanges():
            QMessageBox.critical(
                self, 'Fejl',
                'Kunne ikke tilføje standardfelterne til "%s":\n%s'
                % (layer.name(), '\n'.join(layer.commitErrors())))
            return False
        return True

    def kor(self):
        layer = self._current_layer()
        if not layer:
            QMessageBox.warning(self, 'Fejl', 'Vælg et lag.')
            return

        # Først her ændres laget: standardfelterne oprettes.
        if not self._opret_manglende_felter(layer):
            return

        # Hentes EFTER oprettelsen, så de nye felter er med.
        form_cfg = layer.editFormConfig()
        fields = layer.fields()

        layer.startEditing()

        to_delete = []

        for row in range(self.tblFelter.rowCount()):
            field_name = self.tblFelter.item(row, 0).text()
            new_alias  = self.tblFelter.item(row, 1).text().strip()
            included   = self.tblFelter.item(row, 2).checkState() == Qt.CheckState.Checked
            editable   = self.tblFelter.item(row, 3).checkState() == Qt.CheckState.Checked

            idx = fields.indexOf(field_name)
            if idx < 0:
                continue

            if not included:
                to_delete.append(idx)
                continue

            # Alias
            layer.setFieldAlias(idx, new_alias)

            # Widget-opsætning
            std = next((s for s in STANDARD_FIELDS if s[0] == field_name), None)
            if std:
                layer.setEditorWidgetSetup(idx, QgsEditorWidgetSetup(std[3], std[4]))
            elif layer.editorWidgetSetup(idx).type() == 'Hidden':
                layer.setEditorWidgetSetup(idx, QgsEditorWidgetSetup('TextEdit', {}))

            # Redigerbar
            form_cfg.setReadOnly(idx, not editable)

        layer.setEditFormConfig(form_cfg)

        # Slet fravalgte felter i omvendt rækkefølge så indekser ikke forskydes
        for idx in sorted(to_delete, reverse=True):
            layer.deleteAttribute(idx)

        # Default + udfyld status på nye features (re-fetch efter sletning)
        status_idx = layer.fields().indexOf(STATUS_FIELD)
        if status_idx >= 0:
            layer.setDefaultValueDefinition(status_idx, QgsDefaultValue(f"'{VAL_IKKE}'"))
            for feat in layer.getFeatures():
                if not feat[STATUS_FIELD]:
                    layer.changeAttributeValue(feat.id(), status_idx, VAL_IKKE)

        layer.commitChanges()

        # Farverenderer
        self._apply_renderer(layer)

        # Labels på prøvepunkterne — nummeret skal kunne læses i marken.
        label_felt = self._saet_labels_paa_punkter(layer)

        # Fladerne skal ikke kunne tappes i QField, kun punkterne.
        uvalgbare = self._gor_flader_uvalgbare()

        layer.triggerRepaint()
        QgsProject.instance().setDirty(True)

        linjer = [f'"{layer.name()}" er nu klar til QField.']
        if label_felt:
            linjer.append(f'\nLabels sat med feltet "{label_felt}".')
        elif layer.geometryType() == QgsWkbTypes.PointGeometry:
            linjer.append(f'\nIngen labels: laget har intet "{LABEL_FIELD}"-felt.')
        if uvalgbare:
            linjer.append('\nFladelag gjort uvalgbare (ingen pop-up i QField):')
            linjer.extend(f'  • {n}' for n in uvalgbare)
        QMessageBox.information(self, 'Klargøring færdig', '\n'.join(linjer))
        self.accept()

    @staticmethod
    def _gor_flader_uvalgbare():
        """Slå Identifiable fra på alle fladelag i projektet.

        QField bruger samme flag som QGIS: er et lag ikke identificerbart,
        kan man hverken tappe det eller få feature-formularen op. Det er
        netop det man vil for markerne/gridfladerne — de er baggrund, og man
        skal ikke kunne komme til at ramme dem i stedet for prøvepunktet.
        Punktlag røres ikke; det er dem prøverne registreres på.

        Returnerer navnene på de lag der blev ændret.
        """
        aendrede = []
        for lag in QgsProject.instance().mapLayers().values():
            if lag.type() != lag.VectorLayer:
                continue
            if lag.geometryType() != QgsWkbTypes.PolygonGeometry:
                continue
            flag = lag.flags()
            if not (flag & QgsMapLayer.LayerFlag.Identifiable):
                continue        # allerede uvalgbart
            lag.setFlags(QgsMapLayer.LayerFlags(
                int(flag) & ~int(QgsMapLayer.LayerFlag.Identifiable)))
            aendrede.append(lag.name())
        return aendrede

    @staticmethod
    def _saet_labels_paa_punkter(layer):
        """Labels med grid-nummeret på prøvepunkterne.

        Labels følger med over i QField, så nummeret kan læses i marken
        uden at åbne noget. Omrids om teksten, så den kan læses oven på et
        ortofoto. Kun punktlag — fladerne får ingen labels.

        Returnerer feltnavnet der blev brugt, eller None.
        """
        if layer.geometryType() != QgsWkbTypes.PointGeometry:
            return None
        if layer.fields().indexOf(LABEL_FIELD) < 0:
            return None

        font = QFont('Arial', 10)
        font.setBold(True)
        txt = QgsTextFormat()
        txt.setFont(font)
        txt.setSize(10)
        txt.setColor(QColor('#000000'))
        omrids = QgsTextBufferSettings()
        omrids.setEnabled(True)
        omrids.setSize(1.0)
        omrids.setColor(QColor('#ffffff'))
        txt.setBuffer(omrids)

        opsaetning = QgsPalLayerSettings()
        opsaetning.fieldName = LABEL_FIELD
        opsaetning.placement = Qgis.LabelPlacement.AroundPoint
        opsaetning.dist = 2.0
        opsaetning.setFormat(txt)

        layer.setLabeling(QgsVectorLayerSimpleLabeling(opsaetning))
        layer.setLabelsEnabled(True)
        return LABEL_FIELD

    def _apply_renderer(self, layer):
        geom_type = layer.geometryType()
        if geom_type == QgsWkbTypes.PolygonGeometry:
            sym_ikke    = QgsFillSymbol.createSimple({'color': '#e74c3c', 'outline_color': '#922b21', 'outline_width': '0.4'})
            sym_udtaget = QgsFillSymbol.createSimple({'color': '#2ecc71', 'outline_color': '#1a7a43', 'outline_width': '0.4'})
        else:
            sym_ikke    = QgsMarkerSymbol.createSimple({'color': '#e74c3c', 'outline_color': '#922b21', 'size': '3'})
            sym_udtaget = QgsMarkerSymbol.createSimple({'color': '#2ecc71', 'outline_color': '#1a7a43', 'size': '3'})

        # Opsamlingskategori. UDEN den faar et objekt med en status der ikke
        # er præcis en af de to INTET symbol — og saa tegnes det slet ikke.
        # Et punkt der forsvinder fra kortet er det værste der kan ske her:
        # man tror prøven ikke findes. Grå, saa det ogsaa er til at se at
        # statussen er noget uventet.
        if geom_type == QgsWkbTypes.PolygonGeometry:
            sym_andet = QgsFillSymbol.createSimple(
                {'color': '#bdc3c7', 'outline_color': '#7f8c8d',
                 'outline_width': '0.4'})
        else:
            sym_andet = QgsMarkerSymbol.createSimple(
                {'color': '#bdc3c7', 'outline_color': '#7f8c8d', 'size': '3'})

        categories = [
            QgsRendererCategory(VAL_IKKE,    sym_ikke,    VAL_IKKE),
            QgsRendererCategory(VAL_UDTAGET, sym_udtaget, VAL_UDTAGET),
            QgsRendererCategory('', sym_andet, 'Anden/ukendt status', True),
        ]
        layer.setRenderer(QgsCategorizedSymbolRenderer(STATUS_FIELD, categories))
